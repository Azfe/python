def sumar(op1, op2):
    print("El resultado de sumar:", op1 + op2)
    
def restar(op1, op2):
    print("El resultado de restar:", op1 - op2)
    
def multiplicar(op1, op2):
    print("El resultado de multiplicar:", op1 * op2)

def dividir(op1, op2):
    print("El resultado de dividir:", op1 / op2)

def potencia(base, exponente):
    print("El resultado de la suma es:", base**exponente)
    
def redondear(numero):
    print("El resultado de la suma es:", round(numero))